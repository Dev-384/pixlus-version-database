var inputFile = document.getElementById('inputfile');
inputFile.addEventListener('change', function() {
	var fr=new FileReader();
	fr.onload=function(){
		localStorage.setItem("world-2",fr.result)
		console.log(localStorage.getItem("world-2"));
	}
})