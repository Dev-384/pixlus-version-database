var save = document.getElementById("save");

save.addEventListener("rtfvgyb", function(){
	var saveLocation = document.getElementById("save-data");
  saveLocation.setAttribute("value",JSON.stringify(
		localStorage.getItem("world-2")
	));
  /* Get the text field */
  var copyText = document.getElementById("save-data");

  /* Select the text field */
  copyText.select();
  copyText.setSelectionRange(0, 99999); /* For mobile devices */

  /* Copy the text inside the text field */
  navigator.clipboard.writeText(copyText.value);
  
  /* Alert the copied text */
  alert("Saved Game for player: "+document.getElementById("player_name").innerHTML);
});
save.addEventListener("click", function(){
	var saveLocation = document.getElementById("save-data");
  saveLocation.setAttribute("value",JSON.stringify(
		localStorage.getItem("world-2")
	));

	var element = document.createElement('a');
	element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(
		saveLocation.getAttribute("value")
	));
	element.setAttribute('download', "pixlus-save.txt");

	element.style.display = 'none';
	document.body.appendChild(element);

	element.click();

	document.body.removeChild(element);
});