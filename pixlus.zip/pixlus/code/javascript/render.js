const id = "display";
var canvas = document.getElementById(id);
var ctx = canvas.getContext("2d");
ctx.webkitImageSmoothingEnabled = false;
ctx.mozImageSmoothingEnabled = false;
ctx.imageSmoothingEnabled = false;

/*     NOTE
*  The image ['024'] is a placeholder for an empty slot.
*  The image['000'] is allready in use, so I am using a image that will never exist.
*/
var world = document.getElementById("world").innerHTML;
var game = JSON.parse(sessionStorage.getItem("world-"+world));
var player = {
	frame: 1,
	pos: {
		x: 0,
		y: 0,
		hover:{
			x: 0,
			y: 0
		},
		start:{
			x:5,
			y:5,
		},
	},
	direction:"left",
	speed: 0.5,
	invontory:{

	}
}
function render(){
	window.scrollTo(0,window.scrollY);
	var world = document.getElementById("world").innerHTML;
	var game = JSON.parse(sessionStorage.getItem("world-"+world));
	if(game.paused !== true){
		ctx.clearRect(0, 0, canvas.width, canvas.height);
		blocks(player.pos.x,player.pos.y,game.size);
	}else{}
	ctx.font = "30px Arial";
	ctx.fillText(world,50,50);
}

function blocks(posX,posY,size){
	for(var backY = 0; backY < canvas.height/(size*16)+1; backY++){
		for(var backX = 0; backX < canvas.width/(size*16)+1; backX++){
			image(game.back_fill, backX*(size*16), backY*(size*16),(size*16));
		}
	}
	for(var backY = 0; backY < game.back.length; backY++){
		for(var backX = 0; backX < game.back[backY].length; backX++){
			var icon = game.back[backY][backX];
			var backPosX = (backX*(size*16)+((posX*-1)*(size*16)))+canvas.width*0.5;
			var backPosY = (backY*(size*16)+((posY*-1)*(size*16)))+canvas.height*0.5;
			if(icon !== "081"){
				if(backPosX < canvas.width + 16 * game.size && backPosX > 0 - 16 * game.size){
					if(backPosY < canvas.height + 16 * game.size && backPosY > 0 - 16 * game.size){
						image(icon, backPosX, backPosY,(size*16));
					}
				}
			}
		}
	}
	var playerShow = false;
	for(var middleY=0;middleY < game.middle.length;middleY++){
		for(var middleX = 0; middleX < game.middle[middleY].length; middleX++){
			var icon = game.middle[middleY][middleX];
			var middlePosX = (middleX*(size*16)+((posX*-1)*(size*16)))+canvas.width*0.5;
			var middlePosY = (middleY*(size*16)+((posY*-1)*(size*16)))+canvas.height*0.5;
			if(icon !== "081"){
				if(middlePosX < canvas.width + 16 * game.size && middlePosX+1 > 0 - 16 * game.size){
					if(middlePosY < canvas.height + 16 * game.size && middlePosY > 0 - 16 * game.size){
						image(icon, middlePosX, middlePosY,(size*16));
					}
				}
			}
			if(middleX === Math.round(player.pos.x) && middleY === Math.round(player.pos.y)){
				image(player.frame,canvas.width/2, canvas.height/2,(size*16));
				var playerShow = true;

			}
		}
	}
	for(var frontY = 0; frontY < game.front.length; frontY++){
		for(var frontX = 0; frontX < game.front[frontY].length; frontX++){
			var icon = game.front[frontY][frontX];
			var frontPosX = (frontX*(size*16)+((posX*-1)*(size*16)))+canvas.width*0.5;
			var frontPosY = (frontY*(size*16)+((posY*-1)*(size*16)))+canvas.height*0.5;
			if(icon !== "081"){
				if(frontPosX < canvas.width + 16 * game.size && frontPosX > 0 - 16 * game.size){
					if(frontPosY < canvas.height + 16 * game.size && frontPosY > 0 - 16 * game.size){
						image(icon, frontPosX, frontPosY,(size*16));
					}
				}
			}
		}
	}
		var hoverPosX = (player.pos.hover.x*(size*16)+((posX*-1)*(size*16)))+canvas.width*0.5;
		var hoverPosY = (player.pos.hover.y*(size*16)+((posY*-1)*(size*16)))+canvas.height*0.5;
		ctx.beginPath();
		ctx.lineWidth = "5";
		if(player.pos.hover.x < 0 || player.pos.y < 0){
			ctx.strokeStyle = "darkred";
		}else{
			ctx.strokeStyle = "darkgrey";
		}
		ctx.rect(hoverPosX-16*game.size/2,hoverPosY-16*game.size/2,16*game.size,16*game.size);
		ctx.stroke();
	if(playerShow !== true || getBlock(player.pos.x,player.pos.y)=== '081'){
		playerKill(`You went out of the world!\nLeaving the world lets the demons grab you.`);
	}
}

function playerKill(reason){
	player.pos.x = player.pos.start.x;
	player.pos.y = player.pos.start.y;
	alert(reason);
}
function image(img,x,y,size){
	var myImage = document.createElement('img');
	ctx.globalAlpha = 1;
	myImage.src = 'code/assets/blocks/tile'+img+'.png';
	if(img === player.frame){
		ctx.globalAlpha = 0.75;
		myImage.src = 'code/assets/player/'+player.direction+'/frame_'+player.frame+'.png';
	}
		ctx.drawImage(myImage, x-size/2, y-size/2, size, size);
}
function getBlock(x,y){
	return(game.middle[Math.round(y)][Math.round(x)]);
}
/*               GAME               */
var playerLoop = setInterval(function() {
	player.frame = (player.frame + 1) % 3;
},250);

var gameLoop = setInterval(function() {
	selectBlock();
	render();
},100);
/*               CANVAS CONTROLS               */
addEventListener("mousemove", function(e){
	var innerMouse = {
		X: e.x - 390,
		Y: e.y - 390
	};
	var MouseBlockX = Math.round(innerMouse.X / 16 / game.size) + Math.round(player.pos.x);
	var MouseBlockY = Math.round(innerMouse.Y / 16 / game.size) + Math.round(player.pos.y);
	player.pos.hover.x = MouseBlockX;
	player.pos.hover.y = MouseBlockY;
	render();
});
canvas.addEventListener("click", function(e){
	game.middle[player.pos.hover.y][player.pos.hover.x] = sessionStorage.getItem("pickedBlock");
	render();
});
function selectBlock(){
	var selectBlock = document.getElementById("selectBlock");
	let img = "code/assets/blocks/tile"+sessionStorage.getItem("pickedBlock")+".png"
	selectBlock.setAttribute("src",img);
}
addEventListener("keypress", function(e){
	let key = e.key;
	if(game.paused !== true){
		if(key == 'w' || key == 'W'){
			player.pos.y -= player.speed;
		}
		if(key == 's' || key == 'S'){
			player.pos.y += player.speed;
		}
		if(key == 'a' || key == 'A'){
			player.pos.x -= player.speed;
			player.direction = "left";
		}
		if(key == 'd' || key == 'D'){
			player.pos.x += player.speed;
			player.direction = "right";
		}
	}
	if(key === "escape"){
		alert("Pause button pressed");
		if(game.paused){
			game.paused = false;
		}else{
			game.paused = true;
		}
	}
});
window.onload = function(){
	player.pos.x = player.pos.start.x;
	player.pos.y = player.pos.start.y;
}
window.addEventListener('beforeunload', function (e) {
	e.preventDefault();
	e.returnValue = '';
});