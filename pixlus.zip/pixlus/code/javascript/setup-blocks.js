sessionStorage.setItem("pickedBlock", "000");
const baseImg = document.getElementById("game");
var idx = 0;
for (let i = 0; i < baseImg.height/16; i++) {
	for (let ie = 0; ie < baseImg.width/16; ie++){
		var x = document.createElement("IMG");
		var block = idx;
		if(idx < 100){
			var block = "0"+JSON.stringify(idx);
			if(idx < 10){
				var block = "00"+JSON.stringify(idx);
			}
		}
		var img = 'code/assets/blocks/tile'+block+'.png';
		x.setAttribute("src", img);
		x.setAttribute("width", "36");
		x.setAttribute("height", "36");
		x.setAttribute("alt", "render-v2.block:"+block);
		x.setAttribute("title",block);
		x.setAttribute("onclick",'sessionStorage.setItem("pickedBlock", this.getAttribute("title"));');
		document.getElementById("blocks").appendChild(x);
		idx += 1;
	}
	var y = document.createElement("p");
	y.setAttribute("class","seporator");
	document.getElementById("blocks").appendChild(y);
}
/*     PLAYER     */
//   Right
var idx = 0;
for(let iee = 0; iee < 4; iee++){
	var y = document.createElement("IMG");
	var playerImg = 'code/assets/player/right/frame_'+idx+'.png';
		y.setAttribute("src", playerImg);
		y.setAttribute("width", "36");
		y.setAttribute("height", "36");
		y.setAttribute("alt", "render-v2.player.frame:"+idx);
		y.setAttribute("title",idx)
		document.getElementById("blocks").appendChild(y);
		idx += 1;
}
//  Left
var idx = 0;
for(let iee = 0; iee < 4; iee++){
	var y = document.createElement("IMG");
	var playerImg = 'code/assets/player/left/frame_'+idx+'.png';
		y.setAttribute("src", playerImg);
		y.setAttribute("width", "36");
		y.setAttribute("height", "36");
		y.setAttribute("alt", "render-v2.player.frame:"+idx);
		y.setAttribute("title",idx)
		document.getElementById("blocks").appendChild(y);
		idx += 1;
}